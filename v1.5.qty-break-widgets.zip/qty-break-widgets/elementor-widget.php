<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'QtyW_Elementor_Widget' ) ) {

    class QtyW_Elementor_Widget extends \Elementor\Widget_Base {

        public function get_name() {
            return 'qtyw_widget';
        }

        public function get_title() {
            return __( 'Quantity Break Widget', 'qty-break-widgets' );
        }

        public function get_icon() {
            return 'eicon-product-bundle';
        }

        public function get_categories() {
            return [ 'woocommerce-elements' ];
        }

        public function get_keywords() {
            return [ 'quantity', 'break', 'bundle', 'discount' ];
        }

        protected function register_controls() {

            $this->start_controls_section(
                'content_section',
                [
                    'label' => __( 'Content', 'qty-break-widgets' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );

            $this->add_control(
                'mode',
                [
                    'label' => __( 'Widget Mode', 'qty-break-widgets' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'widebundle' => __( 'WideBundle', 'qty-break-widgets' ),
                        'zoorix'     => __( 'Zoorix', 'qty-break-widgets' ),
                        'kaching'    => __( 'Kaching', 'qty-break-widgets' ),
                        'vitals'     => __( 'Vitals', 'qty-break-widgets' ),
                        'wizio'      => __( 'Wizio', 'qty-break-widgets' ),
                    ],
                    'default' => 'widebundle',
                ]
            );

            $this->end_controls_section();
        }

        protected function render() {
            $settings = $this->get_settings_for_display();
            echo do_shortcode('[qty_break_widgets mode="' . esc_attr($settings['mode']) . '"]');
        }

        protected function _content_template() {
            ?>
            <#
            var mode = settings.mode || 'widebundle';
            #>
            {{{ '[qty_break_widgets mode="' + mode + '"]' }}}
            <?php
        }
    }

}
