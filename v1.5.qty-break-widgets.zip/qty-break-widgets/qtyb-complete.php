<?php
/**
 * Plugin Name: Quantity Break Widgets – Shopify-style (Free)
 * Description: Shopify-style quantity-break bundles with dynamic pricing, Gutenberg block, Elementor widget, and visual tier editor.
 * Version: 1.2.0
 * Author: ChatGPT
 * Text Domain: qty-break-widgets
 */

if (!defined('ABSPATH')) exit;

class QtyBreakWidgets {

    public function __construct() {

        // Load translations
        add_action('init', [$this, 'load_textdomain']);

        // Assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_front']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin']);

        // Shortcode
        add_shortcode('qty_break_widgets', [$this, 'render_shortcode']);

        // Product meta
        add_action('add_meta_boxes', [$this, 'register_meta_box']);
        add_action('save_post_product', [$this, 'save_product_meta']);

        // Settings page
        add_action('admin_menu', [$this, 'settings_menu']);
        add_action('admin_init', [$this, 'register_settings']);

        // Cart processing
        add_action('woocommerce_add_cart_item_data', [$this, 'store_unit_price'], 20, 2);
        add_action('woocommerce_before_calculate_totals', [$this, 'apply_unit_price']);

        // Display in cart
        add_filter('woocommerce_get_item_data', [$this, 'display_selected_price'], 10, 2);

        // Gutenberg
        add_action('init', [$this, 'register_gutenberg_block']);

        // Elementor
        add_action('elementor/widgets/register', [$this, 'register_elementor_widget'], 10);
    }

    /** -----------------------
     * i18n
     ------------------------*/
    public function load_textdomain() {
        load_plugin_textdomain('qty-break-widgets', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /** -----------------------
     * FRONTEND + ADMIN ASSETS
     ------------------------*/
    public function enqueue_front() {
        wp_enqueue_style('qtyw-style', plugin_dir_url(__FILE__) . 'assets/qtyw-style.css', [], '1.2.0');
        wp_enqueue_script('qtyw-script', plugin_dir_url(__FILE__) . 'assets/qtyw-script.js', ['jquery'], '1.2.0', true);
        
        // Pass nonce to frontend
        wp_localize_script('qtyw-script', 'QTYW_DATA', [
            'nonce' => wp_create_nonce('qtyw_add_to_cart'),
            'ajax_url' => admin_url('admin-ajax.php')
        ]);
    }

    public function enqueue_admin($hook) {
        // Only load on product edit pages
        if ('post.php' !== $hook && 'post-new.php' !== $hook) {
            return;
        }
        
        global $post;
        if ($post && 'product' !== $post->post_type) {
            return;
        }
        
        wp_enqueue_style('qtyw-admin', plugin_dir_url(__FILE__) . 'assets/qtyw-admin.css', [], '1.2.0');
        
        // Enqueue jQuery UI sortable for drag-and-drop
        wp_enqueue_script('jquery-ui-sortable');
        
        wp_enqueue_script('qtyw-admin', plugin_dir_url(__FILE__) . 'assets/qtyw-admin.js', ['jquery', 'jquery-ui-sortable'], '1.2.0', true);
        wp_localize_script('qtyw-admin', 'QTYW_ADMIN', [
            'nonce' => wp_create_nonce('qtyw_admin_nonce'),
        ]);
    }

    /** -----------------------
     * SHORTCODE OUTPUT
     ------------------------*/
    public function render_shortcode($atts) {
        $atts = shortcode_atts(['mode' => 'widebundle'], $atts);
        
        // Get product ID if we're on a product page
        $product_id = get_the_ID();
        $tiers = [];
        
        if ($product_id && 'product' === get_post_type($product_id)) {
            $tiers_json = get_post_meta($product_id, '_qtyw_tiers', true);
            if ($tiers_json) {
                $tiers = json_decode($tiers_json, true);
            }
        }
        
        // Fallback to defaults if no tiers found
        if (empty($tiers)) {
            $default_tiers = get_option('qtyw_default_tiers', '');
            if ($default_tiers) {
                $tiers = json_decode($default_tiers, true);
            }
        }
        
        // Final fallback
        if (empty($tiers)) {
            $product = wc_get_product($product_id);
            $base_price = $product ? $product->get_price() : 0;
            $tiers = [
                ['min' => 1, 'price' => $base_price, 'note' => ''],
                ['min' => 2, 'price' => $base_price * 0.9, 'note' => '10% off'],
                ['min' => 3, 'price' => $base_price * 0.8, 'note' => '20% off']
            ];
        }
        
        ob_start();
        echo '<div class="qtyw-wrapper" data-mode="' . esc_attr($atts['mode']) . '" data-tiers="' . esc_attr(json_encode($tiers)) . '">';
        
        // Server-side render to avoid flash of unstyled content
        $this->render_widget_html($tiers, $atts['mode']);
        
        echo '</div>';
        return ob_get_clean();
    }

    /**
     * Render widget HTML server-side
     */
    private function render_widget_html($tiers, $mode) {
        if (empty($tiers)) return;
        
        switch ($mode) {
            case 'widebundle':
                $this->render_widebundle($tiers);
                break;
            case 'zoorix':
                $this->render_zoorix($tiers);
                break;
            case 'kaching':
                $this->render_kaching($tiers);
                break;
            case 'vitals':
                $this->render_vitals($tiers);
                break;
            case 'wizio':
                $this->render_wizio($tiers);
                break;
        }
    }

    private function render_widebundle($tiers) {
        echo '<div class="wb-grid">';
        foreach ($tiers as $i => $tier) {
            $recommended = ($i === 1) ? ' recommended' : '';
            echo '<div class="wb-card' . $recommended . '" data-min="' . esc_attr($tier['min']) . '" data-price="' . esc_attr($tier['price']) . '">';
            if (!empty($tier['note'])) {
                echo '<div class="wb-badge">' . esc_html($tier['note']) . '</div>';
            }
            echo '<div class="wb-tier">' . esc_html($tier['min']) . ' × <span class="wb-price">' . wc_price($tier['price']) . '</span></div>';
            if (!empty($tier['note'])) {
                echo '<div class="wb-sub">' . esc_html($tier['note']) . '</div>';
            }
            echo '<div class="wb-select"><button class="qtyw-btn" type="button">' . __('Choose', 'qty-break-widgets') . '</button></div>';
            echo '</div>';
        }
        echo '</div>';
    }

    private function render_zoorix($tiers) {
        echo '<div class="zx-title">' . __('Quantity discounts', 'qty-break-widgets') . '</div>';
        echo '<div class="zx-cards">';
        foreach ($tiers as $i => $tier) {
            echo '<label class="zx-card" data-min="' . esc_attr($tier['min']) . '" data-price="' . esc_attr($tier['price']) . '">';
            echo '<input type="radio" name="zx-tier" ' . ($i === 0 ? 'checked' : '') . ' />';
            echo '<span class="zx-card-label">';
            echo '<div>' . esc_html($tier['min']) . ' – ' . wc_price($tier['price']) . '</div>';
            if (!empty($tier['note'])) {
                echo '<div style="font-size:13px;color:#777">' . esc_html($tier['note']) . '</div>';
            }
            echo '</span></label>';
        }
        echo '</div>';
    }

    private function render_kaching($tiers) {
        echo '<div class="kc-row">';
        foreach ($tiers as $tier) {
            echo '<button class="kc-btn" data-min="' . esc_attr($tier['min']) . '" data-price="' . esc_attr($tier['price']) . '" type="button">';
            echo '<span>' . esc_html($tier['min']) . '</span>';
            echo '<span class="kc-percent">' . wc_price($tier['price']) . '</span>';
            echo '</button>';
        }
        echo '</div>';
    }

    private function render_vitals($tiers) {
        echo '<table class="vt-table"><tr><th>' . __('Quantity', 'qty-break-widgets') . '</th><th>' . __('Price each', 'qty-break-widgets') . '</th></tr>';
        foreach ($tiers as $tier) {
            $class = ($tier['min'] > 1) ? ' class="vt-recommend"' : '';
            echo '<tr' . $class . ' data-min="' . esc_attr($tier['min']) . '" data-price="' . esc_attr($tier['price']) . '">';
            echo '<td>' . esc_html($tier['min']) . '</td>';
            echo '<td>' . wc_price($tier['price']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    private function render_wizio($tiers) {
        echo '<div class="wz-bubble">';
        foreach ($tiers as $tier) {
            $text = !empty($tier['note']) ? $tier['note'] . ' ' : '';
            $text .= $tier['min'] . ' – ' . wc_price($tier['price']);
            echo '<div class="wz-pill" data-min="' . esc_attr($tier['min']) . '" data-price="' . esc_attr($tier['price']) . '">';
            echo esc_html($text);
            echo '</div>';
        }
        echo '</div>';
    }

    /** -----------------------
     * PRODUCT META – TIERS
     ------------------------*/
    public function register_meta_box() {
        add_meta_box(
            'qtyw_meta',
            __('Quantity Break Tiers', 'qty-break-widgets'),
            [$this, 'render_meta_box'],
            'product',
            'normal',
            'default'
        );
    }

    public function render_meta_box($post) {

        wp_nonce_field('qtyw_meta_nonce_action', 'qtyw_meta_nonce');

        $tiers = get_post_meta($post->ID, '_qtyw_tiers', true);
        if (!$tiers) { 
            $tiers = "[]"; 
        }

        ?>

        <div id="qtyw-tier-editor">
            <p class="description">
                <?php _e('Add quantity break tiers for this product. Drag rows to reorder.', 'qty-break-widgets'); ?>
            </p>
            <button type="button" class="button add-tier"><?php _e('Add Tier', 'qty-break-widgets'); ?></button>
            
            <table id="qtyw-tiers-table">
                <thead>
                    <tr>
                        <th><?php _e('Min Qty', 'qty-break-widgets'); ?></th>
                        <th><?php _e('Price', 'qty-break-widgets'); ?></th>
                        <th><?php _e('Note', 'qty-break-widgets'); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>

            <input type="hidden" id="qtyw_tiers_json" name="qtyw_tiers_json"
                   value="<?php echo esc_attr($tiers); ?>">

        </div>

        <?php
    }

    public function save_product_meta($post_id) {

        if (!isset($_POST['qtyw_meta_nonce']) || 
            !wp_verify_nonce($_POST['qtyw_meta_nonce'], 'qtyw_meta_nonce_action')) {
            return;
        }

        if (!current_user_can('edit_product', $post_id)) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (isset($_POST['qtyw_tiers_json'])) {
            $json = wp_unslash($_POST['qtyw_tiers_json']);

            // Validate and sanitize JSON
            $decoded = json_decode($json, true);
            
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                // Validate each tier
                $validated_tiers = $this->validate_tiers($decoded);
                update_post_meta($post_id, '_qtyw_tiers', wp_json_encode($validated_tiers));
            } else {
                // Invalid JSON - delete meta
                delete_post_meta($post_id, '_qtyw_tiers');
            }
        }
    }

    /**
     * Validate and sanitize tier data
     */
    private function validate_tiers($tiers) {
        $validated = [];
        $seen_mins = [];
        
        foreach ($tiers as $tier) {
            if (!isset($tier['min']) || !isset($tier['price'])) {
                continue;
            }
            
            $min = absint($tier['min']);
            $price = floatval($tier['price']);
            $note = isset($tier['note']) ? sanitize_text_field($tier['note']) : '';
            
            // Skip invalid or duplicate min quantities
            if ($min < 1 || in_array($min, $seen_mins)) {
                continue;
            }
            
            // Price must be non-negative
            if ($price < 0) {
                $price = 0;
            }
            
            $seen_mins[] = $min;
            $validated[] = [
                'min' => $min,
                'price' => round($price, 2),
                'note' => $note
            ];
        }
        
        // Sort by min quantity ascending
        usort($validated, function($a, $b) {
            return $a['min'] - $b['min'];
        });
        
        return $validated;
    }

    /** -----------------------
     * SETTINGS PAGE
     ------------------------*/
    public function settings_menu() {
        add_options_page(
            __('Qty Break Widgets', 'qty-break-widgets'),
            __('Qty Break Widgets', 'qty-break-widgets'),
            'manage_options',
            'qtyw-settings',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        register_setting('qtyw_settings_group', 'qtyw_default_mode', [
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'widebundle'
        ]);
        
        register_setting('qtyw_settings_group', 'qtyw_default_tiers', [
            'sanitize_callback' => [$this, 'sanitize_default_tiers']
        ]);
    }

    public function sanitize_default_tiers($value) {
        $decoded = json_decode($value, true);
        
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $validated = $this->validate_tiers($decoded);
            return wp_json_encode($validated);
        }
        
        return '';
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Handle form submission
        if (isset($_POST['qtyw_settings_submit'])) {
            check_admin_referer('qtyw_settings_action', 'qtyw_settings_nonce');
            
            if (isset($_POST['qtyw_default_mode'])) {
                update_option('qtyw_default_mode', sanitize_text_field($_POST['qtyw_default_mode']));
            }
            
            if (isset($_POST['qtyw_default_tiers'])) {
                $sanitized = $this->sanitize_default_tiers(wp_unslash($_POST['qtyw_default_tiers']));
                update_option('qtyw_default_tiers', $sanitized);
            }
            
            echo '<div class="notice notice-success"><p>' . __('Settings saved.', 'qty-break-widgets') . '</p></div>';
        }
        
        $current_mode = get_option('qtyw_default_mode', 'widebundle');
        $current_tiers = get_option('qtyw_default_tiers', '');
        
        ?>
        <div class="wrap">
            <h1><?php _e('Quantity Break Widgets Settings', 'qty-break-widgets'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('qtyw_settings_action', 'qtyw_settings_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="qtyw_default_mode"><?php _e('Default Widget Mode', 'qty-break-widgets'); ?></label>
                        </th>
                        <td>
                            <select name="qtyw_default_mode" id="qtyw_default_mode">
                                <option value="widebundle" <?php selected($current_mode, 'widebundle'); ?>>WideBundle</option>
                                <option value="zoorix" <?php selected($current_mode, 'zoorix'); ?>>Zoorix</option>
                                <option value="kaching" <?php selected($current_mode, 'kaching'); ?>>Kaching</option>
                                <option value="vitals" <?php selected($current_mode, 'vitals'); ?>>Vitals</option>
                                <option value="wizio" <?php selected($current_mode, 'wizio'); ?>>Wizio</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="qtyw_default_tiers"><?php _e('Default Tiers (JSON)', 'qty-break-widgets'); ?></label>
                        </th>
                        <td>
                            <textarea name="qtyw_default_tiers" id="qtyw_default_tiers" rows="10" cols="80" class="large-text code"><?php echo esc_textarea($current_tiers); ?></textarea>
                            <p class="description">
                                <?php _e('Example:', 'qty-break-widgets'); ?>
                                <code>[{"min":1,"price":19.99,"note":""},{"min":2,"price":17.99,"note":"10% off"},{"min":3,"price":15.99,"note":"20% off"}]</code>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Save Settings', 'qty-break-widgets'), 'primary', 'qtyw_settings_submit'); ?>
            </form>
        </div>
        <?php
    }

    /** -----------------------
     * CART PROCESSING
     ------------------------*/
    public function store_unit_price($cart_item_data, $product_id) {
        // Verify nonce for security
        if (isset($_POST['qtyw_unit_price']) && isset($_POST['qtyw_nonce'])) {
            if (wp_verify_nonce($_POST['qtyw_nonce'], 'qtyw_add_to_cart')) {
                $unit_price = floatval($_POST['qtyw_unit_price']);
                
                // Additional validation: ensure price is reasonable
                if ($unit_price >= 0) {
                    $cart_item_data['qtyw_unit_price'] = $unit_price;
                }
            }
        }
        return $cart_item_data;
    }

    public function apply_unit_price($cart) {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        foreach ($cart->get_cart() as $item) {
            if (isset($item['qtyw_unit_price']) && $item['qtyw_unit_price'] > 0) {
                $item['data']->set_price($item['qtyw_unit_price']);
            }
        }
    }

    public function display_selected_price($item_data, $cart_item) {
        if (isset($cart_item['qtyw_unit_price'])) {
            $item_data[] = [
                'name'  => __('Selected Unit Price', 'qty-break-widgets'),
                'value' => wc_price($cart_item['qtyw_unit_price'])
            ];
        }
        return $item_data;
    }

    /** -----------------------
     * GUTENBERG BLOCK
     ------------------------*/
    public function register_gutenberg_block() {
        if (!function_exists('register_block_type')) {
            return;
        }
        
        register_block_type('qtyw/block', [
            'render_callback' => function($attributes) {
                $mode = isset($attributes['mode']) ? $attributes['mode'] : 'widebundle';
                return do_shortcode('[qty_break_widgets mode="' . esc_attr($mode) . '"]');
            }
        ]);
    }

    /** -----------------------
     * ELEMENTOR WIDGET
     ------------------------*/
    public function register_elementor_widget($widgets_manager) {
        if (!did_action('elementor/loaded')) {
            return;
        }

        require_once __DIR__ . '/elementor-widget.php';

        if (class_exists('QtyW_Elementor_Widget')) {
            $widgets_manager->register(new QtyW_Elementor_Widget());
        }
    }
}

new QtyBreakWidgets();
