/**
 * Admin tier editor for Qty Break Widgets
 * - Add / remove rows
 * - Reorder rows (requires jQuery UI sortable)
 * - Save: serialize table rows to hidden JSON field (#qtyw_tiers_json)
 */

jQuery(document).ready(function($){
  // Render existing JSON rows into table
  function renderRowsFromJson() {
    var raw = $('#qtyw_tiers_json').val() || '[]';
    var rows = [];
    try { rows = JSON.parse(raw); } catch(e){ rows = []; }
    var $tbody = $('#qtyw-tiers-table tbody');
    $tbody.empty();
    if (!rows.length) {
      rows = [{min:1, price:'', note:''}];
    }
    rows.forEach(function(r){
      addRow(r.min, r.price, r.note);
    });
  }

  // Add a row to tbody
  function addRow(min, price, note) {
    min = (typeof min === 'undefined' || min === null) ? 1 : min;
    price = (typeof price === 'undefined' || price === null) ? '' : price;
    note = (typeof note === 'undefined' || note === null) ? '' : note;
    var $row = $(
      '<tr>' +
        '<td><input type="number" class="qtyw-min" min="1" value="'+esc(min)+'" style="width:80px;" /></td>' +
        '<td><input type="text" class="qtyw-price" value="'+esc(price)+'" style="width:120px;" /></td>' +
        '<td><input type="text" class="qtyw-note" value="'+esc(note)+'" /></td>' +
        '<td><button type="button" class="button qtyw-remove-row">Remove</button></td>' +
      '</tr>'
    );
    $('#qtyw-tiers-table tbody').append($row);
  }

  // escape helper to avoid HTML injection in admin fields
  function esc(v){
    return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  // initial render
  renderRowsFromJson();

  // Add row button
  $(document).on('click', '.add-tier', function(e){
    e.preventDefault();
    addRow(1,'','');
  });

  // Remove row
  $(document).on('click', '.qtyw-remove-row', function(e){
    e.preventDefault();
    $(this).closest('tr').remove();
  });

  // Make rows sortable if UI available
  if ($.fn.sortable) {
    $('#qtyw-tiers-table tbody').sortable({ axis: 'y' });
  }

  // Save tiers: serialize to hidden field when product form submits
  $('#post').on('submit', function(){
    var rows = [];
    $('#qtyw-tiers-table tbody tr').each(function(){
      var min = parseInt($(this).find('.qtyw-min').val()||1,10);
      var price = parseFloat($(this).find('.qtyw-price').val()||0);
      var note = $(this).find('.qtyw-note').val()||'';
      if (isNaN(min) || min < 1) min = 1;
      if (isNaN(price)) price = 0;
      rows.push({ min: min, price: price, note: note });
    });
    $('#qtyw_tiers_json').val(JSON.stringify(rows));
    // allow normal form submission to continue
  });

  // Also update hidden JSON on explicit Save tiers button if present
  $(document).on('click', '#qtyw-save-tiers', function(e){
    e.preventDefault();
    $('#post').submit();
  });

});