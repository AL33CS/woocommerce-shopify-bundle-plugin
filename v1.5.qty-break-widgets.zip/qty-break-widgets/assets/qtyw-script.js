/**
 * Frontend script for Qty Break Widgets
 * - Renders the selected widget mode into .qtyw-wrapper
 * - Handles click events to set quantity and hidden unit-price input for add-to-cart
 * - Safe defaults and theme-agnostic selectors
 */

(function($){
  'use strict';

  var defaultTiers = [
    { min: 1, price: null, note: '' },
    { min: 2, price: null, note: '10% off' },
    { min: 3, price: null, note: '20% off' }
  ];

  // Render whichever mode you want; this plugin uses server-side rendering in PHP.
  // JS enhances behaviors and populates UI if server didn't render the blocks.
  $(function(){

    $('.qtyw-wrapper').each(function(){
      var $wrap = $(this);
      var mode = $wrap.data('mode') || (window.qtyw_globals && window.qtyw_globals.selected_mode) || 'widebundle';
      // If server already rendered markup (shortcode), don't replace it.
      // But allow a fallback render if container is empty.
      if ($wrap.children().length === 0) {
        renderFallback($wrap, mode);
      }
      attachHandlers($wrap);
    });

    function renderFallback($wrap, mode) {
      var tiers = (window.qtyw_globals && window.qtyw_globals.default_tiers && window.qtyw_globals.default_tiers.length) ? window.qtyw_globals.default_tiers : defaultTiers;
      // if base_price available, fill null prices with computed base price
      var base = (window.qtyw_globals && window.qtyw_globals.base_price) ? parseFloat(window.qtyw_globals.base_price) : 0;
      tiers = tiers.map(function(t, idx){
        if (t.price === null || typeof t.price === 'undefined') {
          if (base) t.price = (idx===0? base : parseFloat((base * (1 - (0.1 * idx))).toFixed(2)));
          else t.price = (idx===0? 0 : 0);
        }
        return t;
      });

      if (mode === 'widebundle') {
        var $grid = $('<div class="wb-grid"></div>');
        tiers.forEach(function(t,i){
          var $card = $('<div class="wb-card'+(i===1?' recommended':'')+'" data-min="'+t.min+'" data-price="'+t.price+'"></div>');
          $card.append('<div class="wb-badge">'+(t.note||'')+'</div>');
          $card.append('<div class="wb-tier">'+t.min+' × <span class="wb-price">'+formatPrice(t.price)+'</span></div>');
          $card.append('<div class="wb-sub">'+(t.note||'')+'</div>');
          $card.append('<div class="wb-select"><button class="qtyw-btn" type="button">'+(window.qtyw_strings && window.qtyw_strings.choose || 'Choose')+'</button></div>');
          $grid.append($card);
        });
        $wrap.append($grid);
      } else if (mode === 'zoorix') {
        var $cards = $('<div class="zx-cards"></div>');
        tiers.forEach(function(t,i){
          var $label = $('<label class="zx-card" data-min="'+t.min+'" data-price="'+t.price+'"></label>');
          $label.append('<input type="radio" name="zx-tier" '+(i===0?'checked':'')+' />');
          $label.append('<span class="zx-card-label"><div>'+t.min+' — <span class="wb-price">'+formatPrice(t.price)+'</span></div><div style="font-size:13px;color:#777">'+(t.note||'')+'</div></span>');
          $cards.append($label);
        });
        $wrap.append('<div class="zx-title">Quantity discounts</div>');
        $wrap.append($cards);
      } else if (mode === 'kaching') {
        var $row = $('<div class="kc-row"></div>');
        tiers.forEach(function(t){
          $row.append('<button class="kc-btn" data-min="'+t.min+'" data-price="'+t.price+'" type="button"><span>'+t.min+'</span><span class="kc-percent">'+formatPrice(t.price)+'</span></button>');
        });
        $wrap.append($row);
      } else if (mode === 'vitals') {
        var $table = $('<table class="vt-table"><tr><th>Quantity</th><th>Price each</th></tr></table>');
        tiers.forEach(function(t){
          var clazz = (t.min>1)? ' class="vt-recommend"' : '';
          $table.append('<tr '+clazz+' data-min="'+t.min+'"><td>'+t.min+'</td><td class="wb-price">'+formatPrice(t.price)+'</td></tr>');
        });
        $wrap.append($table);
      } else {
        var $bubble = $('<div class="wz-bubble"></div>');
        tiers.forEach(function(t){
          $bubble.append('<div class="wz-pill" data-min="'+t.min+'" data-price="'+t.price+'">'+(t.note||'')+' '+t.min+' — '+formatPrice(t.price)+'</div>');
        });
        $wrap.append($bubble);
      }
    }

    function attachHandlers($wrap) {
      // find quantity input on page (WooCommerce default selectors)
      var $qty = $('form.cart input.qty').first();
      if (!$qty.length) $qty = $('#quantity').first();
      if (!$qty.length) { // fallback: create a local qty input
        $qty = $('<input type="number" min="1" value="1" />').appendTo($wrap);
      }

      // Click any element with data-min
      $wrap.on('click', '[data-min]', function(e){
        e.preventDefault();
        var $el = $(this);
        var min = parseInt($el.attr('data-min') || 1, 10);
        var price = parseFloat($el.attr('data-price') || 0);
        if ($qty.length) $qty.val(min).trigger('change');

        // attach hidden unit price to the main form
        var $form = $el.closest('form.cart');
        if (!$form.length) $form = $('form.cart').first();
        if ($form.length) {
          var $hid = $form.find('input[name="qtyw_unit_price"]');
          if (!$hid.length) {
            $hid = $('<input type="hidden" name="qtyw_unit_price" />').appendTo($form);
          }
          $hid.val(price);
        }

        // optional: UI feedback
        $wrap.find('.zx-card, .wz-pill, .kc-btn, .wb-card').removeClass('selected active');
        $el.addClass('selected active');

      });

    }

    // small util
    function formatPrice(value) {
      if (value === null || typeof value === 'undefined') return '$0.00';
      return '$' + parseFloat(value).toFixed(2);
    }

  });

})(jQuery);
// In qtyw-script.js, when setting hidden input:
$hid.val(price);
// Add after it:
var $nonce = $form.find('input[name="qtyw_nonce"]');
if (!$nonce.length) {
    $nonce = $('<input type="hidden" name="qtyw_nonce" />').appendTo($form);
}
$nonce.val(QTYW_DATA.nonce);